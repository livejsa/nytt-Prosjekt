toppbtn = document.getElementById("tiltoppen"); /* Henter knappen ved hjelp av knapp-id-en. */

/* Lager en funksjon som gjør slik at knappen skal dukke opp når brukeren scroller 20px nedover siden. */
window.onscroll = function() {displaybtn()};

function displaybtn() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20){
    toppbtn.style.display = "block";
  } else {
    toppbtn.style.display = "none";
  }
}

/* Lager en funksjon som gjør at når brukeren trykker på knappen blir siden scrollet opp til toppen igjen. */

function toppenFunksjon(){
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
